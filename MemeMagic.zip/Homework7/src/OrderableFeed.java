import java.util.Collections;
import java.util.Comparator;

public class OrderableFeed extends Feed {

	public void sortByCaption() {
		Collections.sort(this.memes);
	}

	public void sortByRating() {
		Collections.sort(this.memes, new CompareMemeByRating());
	}

	public void sortByCreator() {

		Collections.sort(this.memes, new CompareMemeByCreator());

	}
}
