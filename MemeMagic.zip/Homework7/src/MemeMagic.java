import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * MemeMagic Graphical User Interface
 * 
 * This class contains the graphical user interface for the Meme Magic Software
 * 
 * You will need to implement certain portions of this class, marked with
 * comments starting with "TODO" to connect it with your existing code.
 * 
 * This class provides an example layout for the GUI. You are encouraged to be
 * creative in your design. More information about Swing is online at:
 * https://docs.oracle.com/javase/tutorial/uiswing/components/componentlist.html.
 */
public class MemeMagic extends JFrame {

	/**
	 * Serialization string required by extending JFrame
	 */
	private static final long serialVersionUID = 1L;

	private User user;
	private GraphicalMeme currentMeme;

	private String backgroundImageFilename;

	private BorderLayout panelLayout;
	private JLabel backgroundImageFileNameLabel;
	private JLabel imageDisplayLabel;
	private JPanel controlPanel;
	private JPanel memeViewPanel;
	private JPanel panelPane;

	public MemeMagic() {
		this.user = new User();
	}

	public MemeMagic(User user) {
		this.user = user;
	}

	/**
	 * Main method. This method initializes a PhotoViewer, loads images into a
	 * PhotographContainer, then initializes the Graphical User Interface.
	 * 
	 * @param args Optional command-line arguments
	 */
	public static void main(String[] args) {

		// Create a User object for this instance of Meme Magic
		User user = new User();

		// Instantiate the PhotoViewer Class
		MemeMagic myViewer = new MemeMagic(user);

		// Invoke and start the Graphical User Interface
		javax.swing.SwingUtilities.invokeLater(() -> myViewer.initialize());
	}

	/**
	 * Initialize all the GUI components. This method will be called by
	 * SwingUtilities when the application is started.
	 */
	private void initialize() {

		// Tell Java to exit the program when the window is closed
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Tell Java to title the window to Meme Magic
		this.setTitle("Meme Magic");

		// We will use border layout on the main panel, since it is much easier for
		// organizing panels.
		panelLayout = new BorderLayout();
		panelPane = new JPanel(panelLayout);

		// Create a label to display the full image.
		imageDisplayLabel = new JLabel();
		imageDisplayLabel.setHorizontalAlignment(JLabel.CENTER);
		imageDisplayLabel.setPreferredSize(new Dimension(550, 550));

		// Create a panel on which to display the full image
		memeViewPanel = new JPanel(new BorderLayout());
		memeViewPanel.setPreferredSize(new Dimension(550, 550));
		memeViewPanel.add(imageDisplayLabel, BorderLayout.CENTER);

		// Create a panel on which to display the controls for building a Meme
		controlPanel = new JPanel(new BorderLayout());

		// Create a panel that holds BackgroundImage information and give it a title
		JPanel backgroundImagePanel = new JPanel(new BorderLayout());
		backgroundImagePanel.setBorder(BorderFactory.createTitledBorder("Background Image"));

		// Create a panel that provides input for the BackgroundImage fileName
		JPanel backgroundImageFilePanel = new JPanel();

		// Label
		JLabel backgroundImageFileLabel = new JLabel("Filename: ");
		backgroundImageFileLabel.setPreferredSize(new Dimension(100, 20));
		backgroundImageFilePanel.add(backgroundImageFileLabel);

		// Button
		JButton backgroundImageButton = new JButton("Browse");
		backgroundImageFilePanel.add(backgroundImageButton);
		backgroundImageButton.setPreferredSize(new Dimension(85, 20));
		// TODO The button needs a listener
		backgroundImageButton.addActionListener(new OpenButtonListener());

		// Label that will contain the filename of the image
		backgroundImageFileNameLabel = new JLabel("<choose>");
		backgroundImageFilePanel.add(backgroundImageFileNameLabel);
		backgroundImageFileNameLabel.setPreferredSize(new Dimension(265, 20));
		//

		JPanel titlePanel = new JPanel();
		// Title label
		JLabel titleLabel = new JLabel("Title: ");
		titleLabel.setPreferredSize(new Dimension(100, 20));
		titlePanel.add(titleLabel);
		// Title text box
		JTextField titleText = new JTextField(30);
		titlePanel.add(titleText);

		//

		JPanel descriptionPanel = new JPanel();

		// Description Label
		JLabel descriptionLabel = new JLabel("Description: ");
		descriptionLabel.setPreferredSize(new Dimension(100, 20));
		descriptionPanel.add(descriptionLabel);
		// Description Text Box
		JTextField descriptionText = new JTextField(30);
		descriptionPanel.add(descriptionText);

		// Meme JPanel creation
		JPanel memePanel = new JPanel(new BorderLayout());
		memePanel.setBorder(BorderFactory.createTitledBorder("Meme"));
		// JPanel for caption

		JPanel captionPanel = new JPanel();
		// JLabel for the caption

		JLabel captionLabel = new JLabel("Caption:");
		captionLabel.setPreferredSize(new Dimension(100, 20));
		captionPanel.add(captionLabel);
		// JText for caption
		JTextField captionText = new JTextField(30);
		captionPanel.add(captionText);
		// Panel for allign

		JPanel allignPanel = new JPanel();
		// JLabel for vertical allign
		JLabel allignLabel = new JLabel("Vertical Allign:");
		allignLabel.setPreferredSize(new Dimension(100, 20));
		allignPanel.add(allignLabel);
		// Combox for allign
		String[] options = { "top", "bottom", "middle" };
		JComboBox allignment = new JComboBox(options);
		allignment.setPreferredSize(new Dimension(304, 20));
		allignPanel.add(allignment);

		// Add the panels about the BackgroundImage fileName, title, description to the
		// BackgroundImage information panel
		backgroundImagePanel.add(backgroundImageFilePanel, BorderLayout.NORTH);
		backgroundImagePanel.add(titlePanel, BorderLayout.CENTER);
		backgroundImagePanel.add(descriptionPanel, BorderLayout.SOUTH);

		// Add Panels to Meme

		memePanel.add(captionPanel, BorderLayout.NORTH);
		memePanel.add(allignPanel);

		// TODO Complete the Control Panel implementation (with Background Image and
		// Meme panels)

		// Generate Button and Save Button

		// Panel for buttons

		JPanel buttonPanel = new JPanel();

		// Generate Button

		JButton generate = new JButton("Generate");
		generate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String file = backgroundImageFilename;
				BackgroundImage b = new BackgroundImage(file, titleText.getText(), descriptionText.getText());
				currentMeme = new GraphicalMeme(b, captionText.getText(), new User());
				String cap = (String) allignment.getSelectedItem();
				currentMeme.setCaptionVerticalAlign(cap);
				try {
					memeViewPanel.repaint();
					BufferedImage image = currentMeme.compileMeme();
					currentMeme.setCaptionVerticalAlign(allignment.getActionCommand());
					imageDisplayLabel.setIcon(new ImageIcon(image));

				} catch (Exception e1) {
					System.err.println("Select a jpeg file"); //if file is not a jpeg it will prompt

				}

			}

		});
		buttonPanel.add(generate);
		// Save Button

		JButton save = new JButton("Save");
		buttonPanel.add(save);
		save.addActionListener(new SaveButtonListener());

		// Add the BackgroundImage information panel to the control panel
		controlPanel.add(backgroundImagePanel, BorderLayout.NORTH);
		controlPanel.add(memeViewPanel, BorderLayout.EAST);
		controlPanel.add(memePanel);
		controlPanel.add(buttonPanel, BorderLayout.AFTER_LAST_LINE);

		// Add all the panels to the main display based on BorderLayout
		controlPanel.setPreferredSize(new Dimension(500, 570));
		panelPane.add(controlPanel, BorderLayout.WEST);
		panelPane.add(memeViewPanel, BorderLayout.CENTER);

		// Add the panelPane to the contentPane of the Frame (Window)
		this.getContentPane().add(panelPane);

		// Set the preferred size and show the main application window
		this.setPreferredSize(new Dimension(1150, 570));
		this.pack();
		this.setVisible(true);

	}

	/**
	 * ActionListener for the open button. When the button is pressed, this
	 * ActionListener opens a FileChooser, asks the user to choose a JPG image file,
	 * then sets the field backgroundImageFilename in the main class.
	 */
	private class OpenButtonListener implements ActionListener {
		/**
		 * Action performed operation. Opens a save FileChooser, asks the user to choose
		 * a JPG image file, then sets the field backgroundImageFilename in the main
		 * class.
		 * 
		 * @param evt The event that was performed
		 */
		@Override
		public void actionPerformed(ActionEvent evt) {
			JFileChooser chooser2 = new JFileChooser();
			chooser2.setDialogTitle("Choose a Background Image");
			chooser2.setFileFilter(new FileNameExtensionFilter("JPEG Images", "jpg", "jpeg"));
			int returnVal = chooser2.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				backgroundImageFilename = chooser2.getSelectedFile().getAbsolutePath();
				backgroundImageFileNameLabel.setText(backgroundImageFilename);
			}

		}
	}

	/**
	 * ActionListener for the save button. When the button is pressed, this
	 * ActionListener opens a save FileChooser, asks the user to choose a location
	 * and filename, then writes the graphical meme data to a PNG image file.
	 */
	private class SaveButtonListener implements ActionListener {
		/**
		 * Action performed operation. Opens a save FileChooser, asks the user to choose
		 * a location and filename, then writes the graphical meme data to a PNG file.
		 * 
		 * @param evt The event that was performed
		 */
		@Override
		public void actionPerformed(ActionEvent evt) {
			JFileChooser chooser2 = new JFileChooser();
			chooser2.setDialogTitle("Save Meme");
			chooser2.setFileFilter(new FileNameExtensionFilter("PNG Images", "png"));
			int returnVal = chooser2.showSaveDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				String destinationFile = chooser2.getSelectedFile().getAbsolutePath();
				if (!destinationFile.contains(".png"))
					destinationFile += ".png";

				// TODO: Writing an image throws a checked exception that must be handled.
				// Catch the exceptions and provide the user with an appropriate message
				// ImageIO.write(currentMeme.compileMeme(), "png", new File(destinationFile));

				try {
					ImageIO.write(currentMeme.compileMeme(), "png", new File(destinationFile));
				}catch(NullPointerException e) {
					System.err.println("There is no image to save"); //print out if current memes is null
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.err.println("Image file could not be read"); //if image file is 
				} catch (IllegalArgumentException e) {
					System.err.println("Arguement is not valid"); /// save location is invalid or current memes is null
				} catch (Exception e) {
					System.err.println(e);
				}

			}

		}
	}

}
