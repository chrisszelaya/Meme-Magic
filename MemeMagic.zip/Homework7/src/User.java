import java.util.ArrayList;
import java.util.TreeSet;

public class User extends Object implements Comparable<User> {

	String userName;
	ArrayList<Meme> memesCreated;
	TreeSet<Meme> memesViewed;

	public User() {
		this.userName = "default";
		this.memesCreated = new ArrayList<Meme>();
		this.memesViewed = new TreeSet<Meme>();

	}

	public User(String userName) {
		this.userName = userName;
		this.memesCreated = new ArrayList<Meme>();
		this.memesViewed = new TreeSet<Meme>();

	}

	public void rateMeme(Meme meme, int ratingScore) {
		Rating r = new Rating(this, ratingScore);

		meme.addRating(r);

		memesViewed.add(meme);

	}

	public Meme createMeme(BackgroundImage image, String caption) {
		Meme m = new Meme(image, caption, this);
		memesCreated.add(m);

		return m;

	}

	public boolean deleteMeme(Meme meme) {
		if (meme.creator == this && meme.shared == false && memesCreated.contains(meme)) {
			memesCreated.remove(meme);
			return true;
		}

		return false;

	}

	public void shareMeme(Meme meme, Feed feed) {
		meme.shared = true;

		feed.memes.add(meme);

	}

	public boolean rateNextMemeFromFeed(Feed feed, int ratingScore) {

		Meme m = feed.getNewMeme(this);
		if (m != null) {
			this.memesViewed.add(m);
			Rating r = new Rating(this, ratingScore);

			m.addRating(r);

			return true;
		}
		return false;

	}

	public double calculateReputation() {
		double total = 0.0;
		double size = this.memesCreated.size();

		if (memesCreated.size() == 0) {
			return 0.0;
		}

		for (Meme m : memesCreated) {
			total += m.calculateOverallRating();

		}

		return total / size;

	}

	public String toString() {
		return this.getUserName() + " has rated " + "(" + this.memesViewed.size() + ")" + " memes" + ", " + "("
				+ String.format("%.1f", calculateReputation()) + ")";

	}

	public boolean equals(Object o) {
		if (o instanceof User) {
			User o1 = (User) o;
			if (o1.userName == this.userName) {
				return true;
			}

		}

		return false;

	}

	public ArrayList<Meme> getMemesCreated() {
		return memesCreated;

	}

	public TreeSet<Meme> getMemesViewed() {
		return memesViewed;

	}

	public String getUserName() {
		return userName;

	}

	public void setMemesCreated(ArrayList<Meme> memesCreated) {
		this.memesCreated = memesCreated;

	}

	public void setMemesViewed(TreeSet<Meme> memesViewed) {
		this.memesViewed = memesViewed;

	}

	public void setUserName(String userName) {

		this.userName = userName;
	}

	public int compareTo(User other) {
		int i = this.getUserName().compareTo(other.getUserName());
		if (i == 0) {
			if (this.memesCreated.size() > other.memesCreated.size())
				i = -1;
			else if (this.memesCreated.size() < other.memesCreated.size())
				i = 1;
			else {
				i = 0;
			}
		}
		return i;

	}

}