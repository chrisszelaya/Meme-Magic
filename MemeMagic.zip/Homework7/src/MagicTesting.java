
/*public class MagicTesting {

	public static void main(String[] args) {
		BackgroundImage b1= new BackgroundImage("Chris", "ChrisisCoo", "Picture of me");
		BackgroundImage b2= new BackgroundImage("Chris", "ChrisisCool", "Picture of m");
		Feed f= new Feed();
		Feed g= new Feed();
		CompareMemeByRating z= new CompareMemeByRating();
		System.out.println(b1.toString());
		
		User c= new User("John");
		User d= new User("Chris");
		User fa = new User("Chris");
		
		Meme m1= new Meme(b1, "lol", c);
		Meme m2= new Meme(b1,"a",fa);
		Meme m3= new Meme(b1,"l",fa);
		Meme m4= new Meme(b1,"test",d);
		Rating r= new Rating(c,0);
		Rating v= new Rating(c,1);
		Rating s= new Rating(c,1);
		Rating k= new Rating(d,1);
		
		System.out.println(m2.compareTo(m3));
		System.out.println(c.compareTo(d));
		
		System.out.println(b1.compareTo(b2));
		System.out.println(fa.compareTo(d));
		
		System.out.println(z.compare(m1,m3));
		
		m1.toString();
		m2.toString();
		
		
		m1.addRating(r);
		m2.addRating(v);
		m3.addRating(s);
		m4.addRating(k);
		
		
		f.memes.add(m1);
		f.memes.add(m3);
		g.memes.add(m1);
		g.memes.add(m3);
		
		
		f.getNewMeme(d);
		
		//c.deleteMeme(m4);
		//d.deleteMeme(m4);
		//c.shareMeme(m4, f);
		
		//c.calculateReputation();
	
		
		c.memesViewed.add(m1);
		c.memesViewed.add(m2);
		c.memesViewed.add(m3);
		c.memesCreated.add(m1);
		fa.memesCreated.add(m2);
		fa.memesCreated.add(m3);
		d.memesCreated.add(m4);
		
	
		
		System.out.println(f.toString());
		System.out.println(g.toString());
		
		  OrderableFeed feed = new OrderableFeed();
	        
	        // Create a few users
	        User a = new User("user1");
	        User b = new User("user2");
	       
	        // Create one meme 
	        BackgroundImage bi = new BackgroundImage();
	        bi.setImageFileName("filename.jpg");
	        bi.setTitle("Untitled");
	        bi.setDescription("Episode 5 Screeshot");
	        Meme one = b.createMeme(bi, "The Meme Strikes Back");
	       
	        // Create a second meme 
	        bi = new BackgroundImage();
	        bi.setImageFileName("filename2.jpg");
	        bi.setTitle("Another Title");
	        bi.setDescription("Episode 6 Screenshot");
	        Meme two = b.createMeme(bi, "Return of the Meme");
	        
	        // Share the memes on the feed 
	        b.shareMeme(one, feed);
	        b.shareMeme(two, feed);
	        
	        b.compareTo(a);
	        
	        // Sort by Caption 
	        feed.sortByCaption();
	        System.out.println(feed);
	        feed.sortByRating();
	        System.out.println(feed);
	        feed.sortByCreator();
	        System.out.println(feed);
	        // After sorting, the memes should be in the following order:
	        // two (created by b), then one (created by b)
	        // Print to check:
	        System.out.println(feed);

	        // Check that getNewMeme() works for user a (should be Return of the Meme)
	        System.out.println("Check getNewMeme(). Expected Return of the Meme. " + feed.getNewMeme(a));
		

	}

}
*/