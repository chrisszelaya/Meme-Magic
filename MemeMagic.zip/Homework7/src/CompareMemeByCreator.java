import java.util.Comparator;

public class CompareMemeByCreator implements Comparator<Meme> {

	
	public int compare(Meme a, Meme b) {
		int i = a.getCreator().compareTo(b.getCreator());
		if (i == 0) {
			i = (int) -(a.calculateOverallRating() - b.calculateOverallRating());

		}
		if (i == 0)
			i = (a.getCaption().compareTo(b.getCaption()));
		if (i == 0)
			i = a.getBackgroundImage().compareTo(b.getBackgroundImage());
		if (i == 0) {
			i = Boolean.compare(a.shared, b.shared);
		}

		return i;
	}
}
