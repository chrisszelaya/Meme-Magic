
public class BackgroundImage extends Object implements Comparable<BackgroundImage>{

	String imageFileName;
	String title;
	String description;

	public BackgroundImage() {

	}

	public BackgroundImage(String imageFileName, String title, String description) {

		this.imageFileName = imageFileName;
		this.title = title;
		this.description = description;

	}

	@Override
	public String toString() {
		return title + '<' + description + '>';

	}

	@Override
	public boolean equals(Object o) {

		if (this == o) {
			return true;
		}

		else if (!(o instanceof BackgroundImage)) {

			return false;
		}
		BackgroundImage o1 = (BackgroundImage) o;
		if (imageFileName.equals(o1.imageFileName) && title.equals(o1.title) && description.equals(o1.description)) {
			return true;
		}

		return false;
	}

	public void setImageFileName(String newImageFileName) {

		this.imageFileName = newImageFileName;

	}

	public void setTitle(String newTitle) {
		this.title = newTitle;
	}

	public void setDescription(String newDescription) {
		this.description = newDescription;

	}

	public String getImageFileName() {
		return imageFileName;

	}

	public String getTitle() {
		return title;

	}

	public String getDescription() {
		return description;

	}
	public int compareTo(BackgroundImage o) {
		int i = this.getImageFileName().compareTo(o.getImageFileName());
		if(i==0)
		{
			i=this.getTitle().compareTo(o.getTitle());
			if(i==0)

			i=this.getDescription().compareTo(o.getDescription());
		}
		
		return i;
	}

}
