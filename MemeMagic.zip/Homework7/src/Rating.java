/*
 * Homework 6
 * Christopher Zelaya,qft2jk
*
*/
public class Rating extends Object {

	int score;
	User user;

	public Rating() {

		this.score = 0;
		this.user = user;

	}

	public Rating(User user, int score) {

		this.score = score;
		this.user = user;

	}

	@Override
	public String toString() {
		if (getScore() == 1)
			return this.user.userName + " rated as an upvote";
		else if (getScore() == -1) {
			return this.user.userName + " rated as a downvote";

		}

		else {
			return this.user.userName + " rated as a pass";
		}

	}

	public boolean equals(Object o) {
		if (o instanceof Rating) {
			Rating o1 = (Rating) o;
			if (o1.score == this.score)
				if (o1.user == this.user)
					return true;

		}

		return false;

	}

	public boolean setScore(int score) {
		if (score == 1 || score == -1 || score == 0) {
			this.score = score;
			return true;
		} else {

			return false;
		}
	}

	public void setUser(User user) {

		this.user = user;
	}

	public int getScore() {
		return score;

	}

	public User getUser() {
		return user;

	}
}
