import java.util.Comparator;

public class CompareMemeByRating implements Comparator<Meme> {

	public int compare(Meme a, Meme b) {
		int i=0;
		if(a.calculateOverallRating()>b.calculateOverallRating())
			i=-1;
		else if(a.calculateOverallRating()<b.calculateOverallRating())
			i=1;
		else {
			i=0;
		}
		if (i == 0) {
			i = (a.getCaption().compareTo(b.getCaption()));
			if (i == 0) {
				i = a.getBackgroundImage().compareTo(b.getBackgroundImage());
				if (i == 0) {
					i = a.getCreator().compareTo(b.getCreator());
				}

			}

		}
		
		return i;
	}

}
