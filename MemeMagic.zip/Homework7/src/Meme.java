/*
 * Homework 6
 * Christopher Zelaya,qft2jk
*
*/
public class Meme extends Object implements Comparable<Meme> {

	User creator;
	BackgroundImage backgroundImage;
	Rating[] ratings;
	String caption;
	String captionVerticalAlign;
	boolean shared;
	private int counter = 0;

	public Meme() {
		this.ratings = new Rating[10];
		this.backgroundImage = new BackgroundImage();
		this.caption = "";
		this.captionVerticalAlign = "bottom";
		this.creator = new User();
	}

	public Meme(BackgroundImage image, String caption, User creator) {

		this.backgroundImage = image;
		this.caption = caption;
		this.creator = creator;
		this.captionVerticalAlign = "bottom";

		this.ratings = new Rating[10];

	}

	public boolean addRating(Rating rating) {

		if (counter < 10) {
			ratings[counter++] = rating;

		} else if (ratings.length == 10) {

			ratings[9] = rating;
			for (int i = 0; i < 9; i++) {

				ratings[i] = ratings[i + 1];
			}

		}
		return true;

	}

	public double calculateOverallRating() {
		double answers = 0.0;
		for (Rating d : ratings)
			if (d != null)
				answers += d.getScore();
		return answers;
	}

	public String toString() {
		return backgroundImage + " '" + caption + "' " + calculateOverallRating() + " [" + "+1: " + count(1) + ", "
				+ "-1: " + count(-1) + "] " + "- " + "created by " + creator.userName;

	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof Meme) {
			Meme o1 = (Meme) o;
			if (o1.getBackgroundImage() == this.getBackgroundImage() && o1.getCaption() == this.getCaption()
					&& o1.getCreator() == this.getCreator())
				return true;

		}

		return false;
	}

	public BackgroundImage getBackgroundImage() {
		return backgroundImage;

	}

	public void setRatings(Rating[] ratings) {

		this.ratings = ratings;

	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public boolean setCaptionVerticalAlign(String align) {
		if (align == "top" || align == "middle" || align == "bottom") {
			this.captionVerticalAlign = align;
			return true;
		}

		else
			return false;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}

	public void setBackgroundImage(BackgroundImage backgroundImage) {
		this.backgroundImage = backgroundImage;

	}

	public Rating[] getRatings() {
		return ratings;

	}

	public String getCaption() {
		return caption;

	}

	public String getCaptionVerticalAlign() {
		return captionVerticalAlign;

	}

	public boolean getShared() {
		return shared;

	}

	public void setCreator(User creator) {
		this.creator = creator;

	}

	public User getCreator() {
		return creator;

	}

	public int count(int i) {

		int answer = 0;
		for (Rating d : ratings)
			if (d != null)
				if (d.getScore() == i)
					answer++;
		return answer;
	}

	public int compareTo(Meme other) {

		
			int i = this.getCaption().compareTo(other.getCaption());
			if (i == 0) {
				i = this.getBackgroundImage().compareTo(other.getBackgroundImage());
				if (i == 0) {
					if (this.calculateOverallRating() > other.calculateOverallRating())
						i = -1;
					else if (this.calculateOverallRating() < other.calculateOverallRating())
						i = 1;
					else if((this.ratings==null || other.ratings==null)|| this.calculateOverallRating()==other.calculateOverallRating()) {
						i = 0;
					}
					if (i == 0) {
						i = Boolean.compare(this.shared, other.getShared());
					}

				}

			}

			return i;
	}

}
