import java.util.ArrayList;
import java.util.TreeSet;

public class Feed extends Object {

	ArrayList<Meme> memes;

	public Feed() {
		this.memes = new ArrayList<Meme>();

	}

	public Meme getNewMeme(User user) {
		TreeSet<Meme> viewedMemes= user.getMemesViewed();
		ArrayList<Meme> createdMemes= user.getMemesCreated();
		
		for(Meme item:this.memes)
		{
			if(item==null) {
				continue;
		}
			if(!(viewedMemes.contains(item)) && !(createdMemes.contains(item)))
			return item;
		}
		
		
		return null;
	

		

}

	public String toString() {
		String s = "";
		for (Meme elm : memes)
			s += elm.toString() + "\n";

		return s;

	}

	public void setMemes(ArrayList<Meme> memes) {
		this.memes = memes;
	}

	public ArrayList<Meme> getMemes() {

		return memes;
	}

}